'zASCII' Unity project and and 'ASCII Zarkow' shader and related assets is (C)opyright Johan Munkestam / Digital Software. All Rights Reserved.

Non-commercial projects and for studios making less than 100K USD per year, this code, solution and assets is free to use. Others must attain a license.
